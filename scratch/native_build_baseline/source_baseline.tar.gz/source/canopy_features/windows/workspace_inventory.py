"""Offline normalization of workspace names and identifiers from permitted sources.

Pure, in-memory component for the Windows-inspired Shell Pack workspace list.
It never polls, opens sockets, reads the registry, launches processes or
observes a live desktop. A trusted caller supplies one explicit snapshot at a
time; this module only validates, normalizes and reconciles that snapshot.

Future Shell Host / compiled Qt integration must pass trusted snapshots here
explicitly. Using this module alone does not prove a working desktop.
"""
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
import re
import unicodedata

MAX_WORKSPACES = 64
MAX_NAME_BYTES = 128
MAX_IDENTIFIER_BYTES = 64
MAX_PROBLEMS = 32

_IDENTIFIER = re.compile(r"[a-z0-9][a-z0-9-]{0,63}\Z")
_NON_SLUG = re.compile(r"[^a-z0-9]+")

# Tab, LF and CR are the whitespace separators the "collapse whitespace"
# contract intentionally accepts. Every other non-printing scalar is refused
# before str.split() can fold it away or smuggle it into a "valid" name:
# Cc (VT, FF and U+001C-U+001F are Python whitespace but remain controls),
# Cf (zero-width/format characters), Cs (unpaired surrogates), Co (private
# use), Cn (noncharacters) and Zl/Zp (line/paragraph separators). Printable
# text, including Zs spaces that NFKC folds to ASCII space, stays valid.
_WHITESPACE_CONTROLS = frozenset("\t\n\r")
_UNSAFE_CATEGORIES = frozenset({"Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp"})


def _has_disallowed_control(text):
    return any(char not in _WHITESPACE_CONTROLS
               and unicodedata.category(char) in _UNSAFE_CATEGORIES
               for char in text)


class WorkspaceInventoryError(ValueError):
    """Invalid caller configuration or malformed required argument."""


@dataclass(frozen=True)
class Workspace:
    """One normalized workspace. Immutable; identifiers are canonical slugs."""

    identifier: str
    name: str
    source: str


@dataclass(frozen=True)
class WorkspaceProblem:
    location: str
    reason: str


@dataclass(frozen=True)
class WorkspaceInventory:
    """Canonical snapshot ordered by first occurrence, plus skipped-record notes."""

    workspaces: tuple
    problems: tuple
    _identifiers_cache: object = field(default=None, repr=False, compare=False)
    _lookup_cache: object = field(default=None, repr=False, compare=False)

    def identifiers(self):
        """Immutable canonical identifier tuple, built lazily once.

        Both this tuple and the lookup map in ``get()`` are derived from the
        immutable ``workspaces`` tuple, so neither needs invalidation.
        """
        if self._identifiers_cache is None:
            object.__setattr__(
                self, "_identifiers_cache",
                tuple(workspace.identifier for workspace in self.workspaces))
        return self._identifiers_cache

    def get(self, identifier):
        """Exact-case lookup; no path resolution or code execution.

        The id->workspace map is built lazily once. First occurrence wins for
        duplicate identifiers, matching the previous linear scan exactly.
        """
        if self._lookup_cache is None:
            lookup = {}
            for workspace in self.workspaces:
                lookup.setdefault(workspace.identifier, workspace)
            object.__setattr__(self, "_lookup_cache", lookup)
        return self._lookup_cache.get(identifier)


@dataclass(frozen=True)
class Reconciliation:
    """Bounded differences between two inventories, with the new inventory."""

    inventory: WorkspaceInventory
    added: tuple
    removed: tuple
    renamed: tuple
    reordered: tuple


def _text(value, field):
    if type(value) is not str:
        raise WorkspaceInventoryError(field + " must be a string")
    return value


def _byte_length(value):
    """UTF-8 byte length, refusing text that cannot be encoded.

    An unpaired UTF-16 surrogate survives NFKC and whitespace collapse but
    cannot be encoded as UTF-8. Translate that raw ``UnicodeEncodeError`` into
    the module's ``WorkspaceInventoryError`` so record validation stays
    fail-closed: ``build_inventory`` reports such a record as a problem and
    skips it rather than letting the raw exception abort the whole snapshot.
    """
    try:
        return len(value.encode("utf-8", "strict"))
    except UnicodeEncodeError as exc:
        raise WorkspaceInventoryError("text is not valid Unicode") from exc


def _check_permitted(permitted_sources):
    if (type(permitted_sources) is not frozenset or not permitted_sources
            or any(type(source) is not str or not source
                   for source in permitted_sources)):
        raise WorkspaceInventoryError(
            "permitted_sources must be a non-empty frozenset of strings"
        )


def normalize_name(value):
    """NFKC, trim and collapse whitespace; reject empty or control-laden names.

    Tab, LF and CR collapse as whitespace; every other Unicode control is
    rejected before str.split() can hide it (VT, FF and U+001C-U+001F are
    Python whitespace but remain control characters).
    """
    text = unicodedata.normalize("NFKC", _text(value, "name"))
    if _has_disallowed_control(text):
        raise WorkspaceInventoryError("workspace name contains a control character")
    text = " ".join(text.split())
    if not text:
        raise WorkspaceInventoryError("workspace name is empty after normalization")
    if _byte_length(text) > MAX_NAME_BYTES:
        raise WorkspaceInventoryError("workspace name exceeds byte bound")
    return text


def normalize_identifier(value):
    """Casefold and slugify to a stable lowercase identifier."""
    text = unicodedata.normalize("NFKC", _text(value, "identifier"))
    text = _NON_SLUG.sub("-", text.strip().casefold()).strip("-")
    if not text or not _IDENTIFIER.fullmatch(text):
        raise WorkspaceInventoryError("workspace identifier has no usable characters")
    if _byte_length(text) > MAX_IDENTIFIER_BYTES:
        raise WorkspaceInventoryError("workspace identifier exceeds byte bound")
    return text


def normalize_workspace(record, permitted_sources):
    """Normalize one mapping from a permitted source into a Workspace.

    Required fields: source (must be allowlisted) and name. Optional:
    identifier (or id); when absent, a stable slug is derived from the name.
    """
    _check_permitted(permitted_sources)
    if not isinstance(record, Mapping):
        raise WorkspaceInventoryError("workspace record must be a mapping")
    source = _text(record.get("source"), "source")
    if source not in permitted_sources:
        raise WorkspaceInventoryError("workspace source is not permitted")
    name = normalize_name(record.get("name"))
    raw_identifier = record.get("identifier")
    if raw_identifier is None:
        raw_identifier = record.get("id")
    if raw_identifier is None:
        identifier = normalize_identifier(name)
    else:
        identifier = normalize_identifier(raw_identifier)
    return Workspace(identifier=identifier, name=name, source=source)


def build_inventory(records, *, permitted_sources):
    """Validate, normalize and dedupe a snapshot without executing anything.

    Records from non-permitted sources or with invalid fields are skipped and
    reported. Duplicate identifiers keep the first occurrence. Work and memory
    are bounded by MAX_WORKSPACES and MAX_PROBLEMS regardless of input size.
    """
    _check_permitted(permitted_sources)
    if (isinstance(records, (str, bytes, Mapping))
            or not isinstance(records, Iterable)):
        raise WorkspaceInventoryError("records must be an iterable of mappings")

    seen = {}
    problems = []
    for index, record in enumerate(records):
        location = "record[" + str(index) + "]"
        if len(problems) >= MAX_PROBLEMS:
            break
        try:
            workspace = normalize_workspace(record, permitted_sources)
        except WorkspaceInventoryError as exc:
            problems.append(WorkspaceProblem(location, str(exc)))
            continue
        previous = seen.get(workspace.identifier)
        if previous is not None:
            reason = ("duplicate workspace identifier" if previous == workspace
                      else "conflicting duplicate workspace identifier")
            problems.append(WorkspaceProblem(location, reason))
            continue
        if len(seen) >= MAX_WORKSPACES:
            problems.append(WorkspaceProblem(location, "workspace limit reached"))
            continue
        seen[workspace.identifier] = workspace

    return WorkspaceInventory(
        workspaces=tuple(seen.values()),
        problems=tuple(problems),
    )


def reconcile(previous, current):
    """Report added, removed, renamed and reordered shared workspaces."""
    if not isinstance(previous, WorkspaceInventory) or not isinstance(current, WorkspaceInventory):
        raise WorkspaceInventoryError("reconcile requires two WorkspaceInventory objects")

    previous_by_id = {workspace.identifier: workspace for workspace in previous.workspaces}
    current_by_id = {workspace.identifier: workspace for workspace in current.workspaces}
    previous_ids = list(previous_by_id)
    current_ids = list(current_by_id)

    added = tuple(identifier for identifier in current_ids
                  if identifier not in previous_by_id)
    removed = tuple(identifier for identifier in previous_ids
                    if identifier not in current_by_id)
    renamed = tuple(identifier for identifier in current_ids
                    if identifier in previous_by_id
                    and previous_by_id[identifier].name != current_by_id[identifier].name)

    shared_previous = [identifier for identifier in previous_ids if identifier in current_by_id]
    shared_current = [identifier for identifier in current_ids if identifier in previous_by_id]
    # One id->index map per side keeps this step O(n). Repeated list.index()
    # scans here were O(n^2). Positions are computed on the FILTERED shared
    # lists, exactly as the old index() calls did, so results are unchanged.
    previous_positions = {identifier: index
                          for index, identifier in enumerate(shared_previous)}
    current_positions = {identifier: index
                         for index, identifier in enumerate(shared_current)}
    reordered = tuple(identifier for identifier in shared_current
                      if previous_positions[identifier] != current_positions[identifier])

    return Reconciliation(
        inventory=current,
        added=added,
        removed=removed,
        renamed=renamed,
        reordered=reordered,
    )
